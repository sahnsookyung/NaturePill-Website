# NaturePill

Nature has numerous health benefits and has been prescribed to relax and reduce stress, aptly called by some as a “Nature Pill”. Thus, it is important to have access to nature, but there can be restricting factors such as distance or mobility impairments. Virtual nature is a substitute that provides these benefits, and we created a realistic multisensory virtual reality forest environment that incorporates the best environmental designs to maximise relaxation.

The virtual reality environment was built and tested for HTC Vive and its Pro counterparts, using Unity. The codebase can be found on: https://drive.google.com/drive/folders/1zmOewLjTs9kTJ-MoQupTkMakJHEHHG3I
